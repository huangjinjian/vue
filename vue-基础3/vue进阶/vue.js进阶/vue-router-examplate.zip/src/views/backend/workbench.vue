<template>
  <div>
    <div class="block-content">
      这是工作台页面
    </div>
  </div>
</template>

<script>
  export default {
    name: 'Code',
    data () {
      return {}
    }
  }
</script>
<style>

</style>
