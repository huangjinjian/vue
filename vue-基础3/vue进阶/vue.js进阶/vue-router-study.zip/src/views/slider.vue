<template>
  <div class="slider">
    我是slider
  </div>
</template>

<script>
    export default {}
</script>
<style>

</style>
