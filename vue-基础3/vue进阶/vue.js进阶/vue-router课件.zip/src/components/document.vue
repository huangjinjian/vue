<template>
  <div class="a">
    我是文档
    <p id="abc">定位到这个元素</p>
  </div>
</template>

<script>
    export default {}
</script>
<style>

</style>
