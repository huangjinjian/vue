<template>
  <div style="height: 2000px;">
    我是首页
  </div>
</template>

<script>
    export default {
    }
</script>
<style>

</style>
